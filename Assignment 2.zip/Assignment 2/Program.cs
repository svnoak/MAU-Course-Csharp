namespace AssignmentA2
{
    using System;
    class Program
    {
        static void Main(){
            Console.Title = "Selection and iteration in C#";
            new SelectionAndIteration();
            new TemperatureConverter();
            Console.WriteLine("Press any key to continue!");
            Console.ReadLine();
        }
    }
}